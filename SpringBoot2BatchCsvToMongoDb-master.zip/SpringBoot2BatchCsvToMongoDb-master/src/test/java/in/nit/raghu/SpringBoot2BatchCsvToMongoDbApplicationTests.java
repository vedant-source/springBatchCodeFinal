package in.nit.raghu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBoot2BatchCsvToMongoDbApplicationTests {

	@Test
	void contextLoads() {
	}

}
